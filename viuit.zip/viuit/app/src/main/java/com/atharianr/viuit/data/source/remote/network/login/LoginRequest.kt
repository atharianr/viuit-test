package com.atharianr.viuit.data.source.remote.network.login

data class LoginRequest(
    val user: String,
    val password: String
)