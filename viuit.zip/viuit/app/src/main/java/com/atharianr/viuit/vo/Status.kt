package com.atharianr.viuit.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}