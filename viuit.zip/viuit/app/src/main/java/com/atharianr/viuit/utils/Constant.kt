package com.atharianr.viuit.utils

object Constant {
    const val API_BASE_URL = "https://devel.bebasbayar.com/"
}