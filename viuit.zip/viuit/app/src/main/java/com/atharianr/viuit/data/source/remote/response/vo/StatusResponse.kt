package com.atharianr.viuit.data.source.remote.response.vo

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}